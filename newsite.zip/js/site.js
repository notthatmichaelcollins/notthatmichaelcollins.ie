(function () {
  // ---- Email address (assembled in the browser so scrapers don't see it) ----
  document.querySelectorAll('[data-u][data-d]').forEach(function (el) {
    var addr = el.getAttribute('data-u') + '@' + el.getAttribute('data-d');
    if (el.tagName === 'A') el.setAttribute('href', 'mailto:' + addr);
    if (el.getAttribute('data-show') !== 'no') el.textContent = addr;
  });

  // ---- Theme toggle (remembers choice) ----
  var root = document.documentElement;
  var themeBtn = document.querySelector('.theme-toggle');
  try {
    var saved = localStorage.getItem('theme');
    if (saved) root.setAttribute('data-theme', saved);
  } catch (e) {}

  function isDark() {
    var t = root.getAttribute('data-theme');
    if (t) return t === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
  function paint() { if (themeBtn) themeBtn.textContent = isDark() ? '\u2600\uFE0F' : '\uD83C\uDF19'; }
  paint();
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var next = isDark() ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('theme', next); } catch (e) {}
      paint();
    });
  }

  // ---- Photo viewer with next / previous ----
  var box = document.querySelector('.lightbox');
  if (!box) return;
  var img = box.querySelector('img');
  var cap = box.querySelector('figcaption');
  var closeBtn = box.querySelector('.close');
  var prevBtn = box.querySelector('.prev');
  var nextBtn = box.querySelector('.next');
  var items = [], idx = 0, lastFocus = null, startX = null, startY = null;

  function srcs(i) {
    var t = items[i].querySelector('img');
    return { thumb: t.getAttribute('src'), full: t.getAttribute('data-full') || t.getAttribute('src'), alt: t.getAttribute('alt') || '' };
  }
  function preload(i) {
    if (items.length < 2) return;
    var n = new Image();
    n.src = srcs((i + items.length) % items.length).full;
  }
  function show(i) {
    idx = (i + items.length) % items.length;
    var s = srcs(idx);
    var current = idx;
    img.src = s.thumb;                       // instant: the small version
    img.alt = s.alt;
    cap.textContent = s.alt + (items.length > 1 ? '  (' + (idx + 1) + ' / ' + items.length + ')' : '');
    var big = new Image();
    big.onload = function () { if (current === idx) img.src = big.src; };
    big.src = s.full;                        // then swap to the sharp one
    preload(idx + 1); preload(idx - 1);
  }
  function open(btn) {
    var section = btn.closest('section') || document;
    items = Array.prototype.slice.call(section.querySelectorAll('.gallery button, .photo-strip button'));
    lastFocus = document.activeElement;
    box.classList.toggle('single', items.length < 2);
    box.classList.add('open');
    root.classList.add('no-scroll');
    show(items.indexOf(btn));
    closeBtn.focus();
  }
  function close() {
    box.classList.remove('open');
    root.classList.remove('no-scroll');
    img.src = '';
    if (lastFocus) lastFocus.focus();
  }

  document.querySelectorAll('.gallery button, .photo-strip button').forEach(function (b) {
    b.addEventListener('click', function () { open(b); });
  });
  closeBtn.addEventListener('click', close);
  prevBtn.addEventListener('click', function (e) { e.stopPropagation(); show(idx - 1); });
  nextBtn.addEventListener('click', function (e) { e.stopPropagation(); show(idx + 1); });
  box.addEventListener('click', function (e) { if (e.target === box) close(); });
  document.addEventListener('keydown', function (e) {
    if (!box.classList.contains('open')) return;
    if (e.key === 'Escape') close();
    else if (e.key === 'ArrowLeft') show(idx - 1);
    else if (e.key === 'ArrowRight') show(idx + 1);
  });
  box.addEventListener('touchstart', function (e) {
    startX = e.changedTouches[0].clientX; startY = e.changedTouches[0].clientY;
  }, { passive: true });
  box.addEventListener('touchend', function (e) {
    if (startX === null) return;
    var dx = e.changedTouches[0].clientX - startX, dy = e.changedTouches[0].clientY - startY;
    startX = null;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) show(dx < 0 ? idx + 1 : idx - 1);
  }, { passive: true });
})();
